class SupabaseConfig {
  static const String url = 'https://ouetjtymbjvmdkomqxkd.supabase.co';
  static const String anonKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im91ZXRqdHltYmp2bWRrb21xeGtkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc4NDUzMzIsImV4cCI6MjA2MzQyMTMzMn0.yY0TdhvCAzy1dJ7oo9KDryEF4Rf11yN5Mq5SvhmaJZM';
}
