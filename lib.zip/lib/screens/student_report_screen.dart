import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tution/models/student.dart';
import 'package:tution/models/payment.dart';
import 'package:tution/providers/student_provider.dart';
import 'package:tution/providers/payment_provider.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:http/http.dart' as http;

class StudentReportScreen extends StatefulWidget {
  final String studentId;

  const StudentReportScreen({super.key, required this.studentId});

  @override
  State<StudentReportScreen> createState() => _StudentReportScreenState();
}

class _StudentReportScreenState extends State<StudentReportScreen> {
  final DateFormat _dateFormat = DateFormat('dd MMM yyyy');
  final DateFormat _timeFormat = DateFormat('hh:mm a');
  final DateFormat _fullDateFormat = DateFormat('dd MMM yyyy, hh:mm a');

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<StudentProvider>(context, listen: false)
          .loadStudentById(widget.studentId);
      Provider.of<PaymentProvider>(context, listen: false)
          .loadPaymentsByStudentId(widget.studentId);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Student Report'),
        actions: [
          IconButton(
            icon: const Icon(Icons.print),
            onPressed: () => _generatePDF(context),
          ),
        ],
      ),
      body: Consumer2<StudentProvider, PaymentProvider>(
        builder: (context, studentProvider, paymentProvider, child) {
          final student = studentProvider.getStudentById(widget.studentId);

          if (student == null) {
            return const Center(child: Text('Student not found'));
          }

          final payments =
              paymentProvider.getPaymentsByStudentId(widget.studentId);

          if (paymentProvider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildStudentHeader(student),
                const SizedBox(height: 24),
                _buildFeesOverview(student),
                const SizedBox(height: 24),
                _buildPaymentTimeline(student, payments),
                const SizedBox(height: 24),
                _buildPaymentChart(payments),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildStudentHeader(Student student) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              radius: 40,
              backgroundImage: student.photoUrl != null
                  ? NetworkImage(student.photoUrl!)
                  : null,
              child: student.photoUrl == null
                  ? Text(
                      student.name[0].toUpperCase(),
                      style: const TextStyle(fontSize: 30),
                    )
                  : null,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    student.name,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text('Class: ${student.standard}'),
                  const SizedBox(height: 4),
                  Text('School: ${student.schoolName}'),
                  const SizedBox(height: 4),
                  Text(
                    'Admission Date: ${_dateFormat.format(student.createdAt)}',
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeesOverview(Student student) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Fees Overview',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Divider(),
            _buildInfoRow(
                'Total Fees', '₹${student.totalFees.toStringAsFixed(2)}'),
            _buildInfoRow(
                'Fees Paid', '₹${student.feesSubmitted.toStringAsFixed(2)}'),
            _buildInfoRow(
              'Remaining Fees',
              '₹${student.remainingFees.toStringAsFixed(2)}',
              valueColor: student.remainingFees > 0 ? Colors.red : Colors.green,
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: student.feesPercentage / 100,
              minHeight: 10,
              backgroundColor: Colors.grey[300],
              valueColor: AlwaysStoppedAnimation<Color>(
                student.feesPercentage < 100 ? Colors.orange : Colors.green,
              ),
            ),
            const SizedBox(height: 8),
            Center(
              child: Text(
                '${student.feesPercentage.toStringAsFixed(1)}% Complete',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPaymentTimeline(Student student, List<Payment> payments) {
    if (payments.isEmpty) {
      return Card(
        elevation: 4,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text(
                'Payment History',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Divider(),
              Center(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('No payment records found'),
                ),
              ),
            ],
          ),
        ),
      );
    }

    // Sort payments by date (newest first)
    final sortedPayments = List<Payment>.from(payments)
      ..sort((a, b) => b.paymentDate.compareTo(a.paymentDate));

    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Payment History',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Divider(),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: sortedPayments.length,
              itemBuilder: (context, index) {
                final payment = sortedPayments[index];
                final isFirst = index == 0;
                final isLast = index == sortedPayments.length - 1;

                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 80,
                      child: Text(
                        _dateFormat.format(payment.paymentDate),
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 12,
                        ),
                      ),
                    ),
                    Column(
                      children: [
                        Container(
                          width: 20,
                          height: isFirst ? 20 : 30,
                          alignment: Alignment.center,
                          child: isFirst
                              ? null
                              : VerticalDivider(
                                  color: Colors.grey[400],
                                  thickness: 2,
                                ),
                        ),
                        Container(
                          width: 20,
                          height: 20,
                          decoration: BoxDecoration(
                            color: Colors.blue,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white,
                              width: 3,
                            ),
                          ),
                        ),
                        Container(
                          width: 20,
                          height: isLast ? 20 : 30,
                          alignment: Alignment.center,
                          child: isLast
                              ? null
                              : VerticalDivider(
                                  color: Colors.grey[400],
                                  thickness: 2,
                                ),
                        ),
                      ],
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                '₹${payment.amount.toStringAsFixed(2)}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                              Text(
                                _timeFormat.format(payment.paymentDate),
                                style: TextStyle(
                                  color: Colors.grey[600],
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Payment Mode: ${payment.paymentMode}',
                            style: TextStyle(
                              color: Colors.grey[600],
                            ),
                          ),
                          if (payment.notes != null &&
                              payment.notes!.isNotEmpty) ...[
                            const SizedBox(height: 4),
                            Text(
                              payment.notes!,
                              style: const TextStyle(
                                fontStyle: FontStyle.italic,
                              ),
                            ),
                          ],
                          const SizedBox(height: 16),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPaymentChart(List<Payment> payments) {
    if (payments.isEmpty) {
      return const SizedBox.shrink();
    }

    // Sort payments by date (oldest first)
    final sortedPayments = List<Payment>.from(payments)
      ..sort((a, b) => a.paymentDate.compareTo(b.paymentDate));

    // Calculate cumulative payments
    double cumulativeAmount = 0;
    final cumulativeData = <FlSpot>[];

    for (int i = 0; i < sortedPayments.length; i++) {
      cumulativeAmount += sortedPayments[i].amount;
      cumulativeData.add(FlSpot(
        i.toDouble(),
        cumulativeAmount,
      ));
    }

    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Payment Progress',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Divider(),
            const SizedBox(height: 8),
            SizedBox(
              height: 200,
              child: LineChart(
                LineChartData(
                  gridData: FlGridData(
                    show: true,
                    drawVerticalLine: false,
                  ),
                  titlesData: FlTitlesData(
                    show: true,
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          if (value.toInt() >= sortedPayments.length ||
                              value.toInt() % 2 != 0) {
                            return const SizedBox.shrink();
                          }
                          return Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Text(
                              _dateFormat.format(
                                  sortedPayments[value.toInt()].paymentDate),
                              style: const TextStyle(fontSize: 10),
                            ),
                          );
                        },
                      ),
                    ),
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 40,
                        getTitlesWidget: (value, meta) {
                          return Text(
                            '₹${value.toInt()}',
                            style: const TextStyle(fontSize: 10),
                          );
                        },
                      ),
                    ),
                    topTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                    rightTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                  ),
                  borderData: FlBorderData(
                    show: true,
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  minX: 0,
                  maxX: (sortedPayments.length - 1).toDouble(),
                  minY: 0,
                  lineBarsData: [
                    LineChartBarData(
                      spots: cumulativeData,
                      isCurved: false,
                      color: Colors.blue,
                      barWidth: 3,
                      isStrokeCapRound: true,
                      dotData: FlDotData(show: true),
                      belowBarData: BarAreaData(
                        show: true,
                        color: Colors.blue.withOpacity(0.2),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value, {Color? valueColor}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              color: Colors.grey[600],
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: valueColor,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _generatePDF(BuildContext context) async {
    final student = Provider.of<StudentProvider>(context, listen: false)
        .getStudentById(widget.studentId);
    final payments = Provider.of<PaymentProvider>(context, listen: false)
        .getPaymentsByStudentId(widget.studentId);

    if (student == null) return;

    final pdf = pw.Document();

    // Add student image if available
    pw.MemoryImage? studentImage;
    if (student.photoUrl != null) {
      try {
        final response = await http.get(Uri.parse(student.photoUrl!));
        if (response.statusCode == 200) {
          studentImage = pw.MemoryImage(response.bodyBytes);
        }
      } catch (e) {
        // Handle image loading error
      }
    }

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        header: (pw.Context context) {
          return pw.Header(
            level: 0,
            child: pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text(
                  'Student Fee Report',
                  style: pw.TextStyle(
                    fontSize: 24,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
                pw.Text(
                  'Generated: ${_fullDateFormat.format(DateTime.now())}',
                  style: const pw.TextStyle(
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          );
        },
        build: (pw.Context context) {
          return [
            // Student Information
            pw.Row(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                if (studentImage != null)
                  pw.Container(
                    width: 80,
                    height: 80,
                    decoration: pw.BoxDecoration(
                      shape: pw.BoxShape.circle,
                      image: pw.DecorationImage(
                        image: studentImage,
                        fit: pw.BoxFit.cover,
                      ),
                    ),
                  )
                else
                  pw.Container(
                    width: 80,
                    height: 80,
                    decoration: const pw.BoxDecoration(
                      shape: pw.BoxShape.circle,
                      color: PdfColors.grey300,
                    ),
                    alignment: pw.Alignment.center,
                    child: pw.Text(
                      student.name[0].toUpperCase(),
                      style: pw.TextStyle(
                        fontSize: 30,
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                  ),
                pw.SizedBox(width: 16),
                pw.Expanded(
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text(
                        student.name,
                        style: pw.TextStyle(
                          fontSize: 20,
                          fontWeight: pw.FontWeight.bold,
                        ),
                      ),
                      pw.SizedBox(height: 4),
                      pw.Text('Class: ${student.standard}'),
                      pw.SizedBox(height: 4),
                      pw.Text('School: ${student.schoolName}'),
                      pw.SizedBox(height: 4),
                      pw.Text('Contact: ${student.parentNumber}'),
                      pw.SizedBox(height: 4),
                      pw.Text('Address: ${student.address}'),
                      pw.SizedBox(height: 4),
                      pw.Text(
                        'Admission Date: ${_dateFormat.format(student.createdAt)}',
                        style: const pw.TextStyle(
                          fontSize: 12,
                          color: PdfColors.grey700,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            pw.SizedBox(height: 24),

            // Fees Overview
            pw.Container(
              padding: const pw.EdgeInsets.all(16),
              decoration: pw.BoxDecoration(
                border: pw.Border.all(color: PdfColors.grey300),
                borderRadius: pw.BorderRadius.circular(8),
              ),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(
                    'Fees Overview',
                    style: pw.TextStyle(
                      fontSize: 16,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                  pw.Divider(),
                  _buildPdfInfoRow(
                      'Total Fees', '₹${student.totalFees.toStringAsFixed(2)}'),
                  _buildPdfInfoRow('Fees Paid',
                      '₹${student.feesSubmitted.toStringAsFixed(2)}'),
                  _buildPdfInfoRow(
                    'Remaining Fees',
                    '₹${student.remainingFees.toStringAsFixed(2)}',
                    valueColor: student.remainingFees > 0
                        ? PdfColors.red
                        : PdfColors.green,
                  ),
                  pw.SizedBox(height: 8),
                  pw.Container(
                    height: 10,
                    decoration: pw.BoxDecoration(
                      color: PdfColors.grey300,
                      borderRadius: pw.BorderRadius.circular(5),
                    ),
                    child: pw.Stack(
                      children: [
                        pw.Container(
                          width: (student.feesPercentage / 100) *
                              500, // Approximate width
                          decoration: pw.BoxDecoration(
                            color: student.feesPercentage < 100
                                ? PdfColors.orange
                                : PdfColors.green,
                            borderRadius: pw.BorderRadius.circular(5),
                          ),
                        ),
                      ],
                    ),
                  ),
                  pw.SizedBox(height: 8),
                  pw.Center(
                    child: pw.Text(
                      '${student.feesPercentage.toStringAsFixed(1)}% Complete',
                      style: pw.TextStyle(
                        fontWeight: pw.FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            pw.SizedBox(height: 24),

            // Payment History
            pw.Container(
              padding: const pw.EdgeInsets.all(16),
              decoration: pw.BoxDecoration(
                border: pw.Border.all(color: PdfColors.grey300),
                borderRadius: pw.BorderRadius.circular(8),
              ),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(
                    'Payment History',
                    style: pw.TextStyle(
                      fontSize: 16,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                  pw.Divider(),
                  if (payments.isEmpty)
                    pw.Center(
                      child: pw.Padding(
                        padding: const pw.EdgeInsets.all(16),
                        child: pw.Text('No payment records found'),
                      ),
                    )
                  else
                    pw.Table(
                      border: pw.TableBorder.all(color: PdfColors.grey300),
                      children: [
                        pw.TableRow(
                          decoration:
                              const pw.BoxDecoration(color: PdfColors.grey200),
                          children: [
                            pw.Padding(
                              padding: const pw.EdgeInsets.all(8),
                              child: pw.Text(
                                'Date',
                                style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold),
                              ),
                            ),
                            pw.Padding(
                              padding: const pw.EdgeInsets.all(8),
                              child: pw.Text(
                                'Amount',
                                style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold),
                              ),
                            ),
                            pw.Padding(
                              padding: const pw.EdgeInsets.all(8),
                              child: pw.Text(
                                'Mode',
                                style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold),
                              ),
                            ),
                            pw.Padding(
                              padding: const pw.EdgeInsets.all(8),
                              child: pw.Text(
                                'Notes',
                                style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                        ...payments.map((payment) {
                          return pw.TableRow(
                            children: [
                              pw.Padding(
                                padding: const pw.EdgeInsets.all(8),
                                child: pw.Text(_fullDateFormat
                                    .format(payment.paymentDate)),
                              ),
                              pw.Padding(
                                padding: const pw.EdgeInsets.all(8),
                                child: pw.Text(
                                    '₹${payment.amount.toStringAsFixed(2)}'),
                              ),
                              pw.Padding(
                                padding: const pw.EdgeInsets.all(8),
                                child: pw.Text(payment.paymentMode),
                              ),
                              pw.Padding(
                                padding: const pw.EdgeInsets.all(8),
                                child: pw.Text(payment.notes ?? '-'),
                              ),
                            ],
                          );
                        }).toList(),
                      ],
                    ),
                ],
              ),
            ),

            pw.SizedBox(height: 24),
            pw.Center(
              child: pw.Text(
                'End of Report',
                style: const pw.TextStyle(
                  color: PdfColors.grey,
                  fontSize: 12,
                ),
              ),
            ),
          ];
        },
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
    );
  }

  pw.Widget _buildPdfInfoRow(String label, String value,
      {PdfColor? valueColor}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 4),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            label,
            style: const pw.TextStyle(
              color: PdfColors.grey700,
            ),
          ),
          pw.Text(
            value,
            style: pw.TextStyle(
              fontWeight: pw.FontWeight.bold,
              color: valueColor,
            ),
          ),
        ],
      ),
    );
  }
}
