import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tution/models/student.dart';
import 'package:tution/providers/student_provider.dart';
import 'package:tution/screens/add_edit_student_screen.dart';
import 'package:tution/screens/student_details_screen.dart';
import 'package:tution/screens/analytics_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _searchQuery = '';
  String? _selectedSchool;
  String? _selectedStandard;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<StudentProvider>(context, listen: false).loadStudents();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tuition Management'),
        actions: [
          IconButton(
            icon: const Icon(Icons.analytics),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const AnalyticsScreen(),
                ),
              );
            },
          ),
        ],
      ),
      body: Consumer<StudentProvider>(
        builder: (context, provider, child) {
          if (provider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (provider.error != null) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Error: ${provider.error}'),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () {
                      provider.loadStudents();
                    },
                    child: const Text('Retry'),
                  ),
                ],
              ),
            );
          }

          if (provider.students.isEmpty) {
            return const Center(
              child: Text('No students found. Add a student to get started.'),
            );
          }

          // Get unique school names and standards for filters
          final schools = provider.students
              .map((s) => s.schoolName)
              .toSet()
              .toList()
            ..sort();
          final standards =
              provider.students.map((s) => s.standard).toSet().toList()..sort();

          // Filter students
          final filteredStudents = provider.students.where((student) {
            final matchesName =
                student.name.toLowerCase().contains(_searchQuery.toLowerCase());
            final matchesSchool = _selectedSchool == null ||
                student.schoolName == _selectedSchool;
            final matchesStandard = _selectedStandard == null ||
                student.standard == _selectedStandard;
            return matchesName && matchesSchool && matchesStandard;
          }).toList();

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  decoration: const InputDecoration(
                    labelText: 'Search by name',
                    prefixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0),
                child: Row(
                  children: [
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: _selectedSchool,
                        decoration: const InputDecoration(
                          labelText: 'Filter by School',
                          border: OutlineInputBorder(),
                        ),
                        items: [
                          const DropdownMenuItem<String>(
                            value: null,
                            child: Text('All Schools'),
                          ),
                          ...schools.map((school) => DropdownMenuItem<String>(
                                value: school,
                                child: Text(school),
                              )),
                        ],
                        onChanged: (value) {
                          setState(() {
                            _selectedSchool = value;
                          });
                        },
                        isExpanded: true,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: _selectedStandard,
                        decoration: const InputDecoration(
                          labelText: 'Filter by Standard',
                          border: OutlineInputBorder(),
                        ),
                        items: [
                          const DropdownMenuItem<String>(
                            value: null,
                            child: Text('All Standards'),
                          ),
                          ...standards.map((std) => DropdownMenuItem<String>(
                                value: std,
                                child: Text(std),
                              )),
                        ],
                        onChanged: (value) {
                          setState(() {
                            _selectedStandard = value;
                          });
                        },
                        isExpanded: true,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: filteredStudents.isEmpty
                    ? const Center(
                        child: Text('No students match your search/filter.'))
                    : ListView.builder(
                        itemCount: filteredStudents.length,
                        itemBuilder: (context, index) {
                          final student = filteredStudents[index];
                          return StudentListItem(student: student);
                        },
                      ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const AddEditStudentScreen(),
            ),
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}

class StudentListItem extends StatelessWidget {
  final Student student;

  const StudentListItem({super.key, required this.student});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: ListTile(
        leading: CircleAvatar(
          backgroundImage:
              student.photoUrl != null ? NetworkImage(student.photoUrl!) : null,
          child: student.photoUrl == null
              ? Text(student.name[0].toUpperCase())
              : null,
        ),
        title: Text(student.name),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Class: ${student.standard}'),
            Text(
              'Fees: ₹${student.feesSubmitted.toStringAsFixed(2)} / ₹${student.totalFees.toStringAsFixed(2)}',
            ),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              '${student.feesPercentage.toStringAsFixed(0)}%',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            Text(
              'Pending: ₹${student.remainingFees.toStringAsFixed(2)}',
              style: TextStyle(
                color: student.remainingFees > 0 ? Colors.red : Colors.green,
                fontSize: 12,
              ),
            ),
          ],
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => StudentDetailsScreen(studentId: student.id),
            ),
          );
        },
      ),
    );
  }
}
