import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tution/providers/student_provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:printing/printing.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:tution/models/student.dart';
import 'package:tution/models/payment.dart';
import 'package:pdf/pdf.dart';

class AnalyticsScreen extends StatefulWidget {
  const AnalyticsScreen({super.key});

  @override
  State<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen> {
  Map<String, dynamic>? _analytics;
  bool _isLoading = true;
  List<MapEntry<String, int>> _standardCounts = [];
  List<MapEntry<String, int>> _schoolCounts = [];

  @override
  void initState() {
    super.initState();
    _loadAnalytics();
    _loadStandardAndSchoolDistribution();
  }

  Future<void> _loadAnalytics() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final analytics =
          await Provider.of<StudentProvider>(context, listen: false)
              .getFeesAnalytics();
      setState(() {
        _analytics = analytics;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error loading analytics: $e')),
      );
    }
  }

  Future<void> _loadStandardAndSchoolDistribution() async {
    final students =
        Provider.of<StudentProvider>(context, listen: false).students;
    final Map<String, int> standardMap = {};
    final Map<String, int> schoolMap = {};
    for (var student in students) {
      final standard = (student.standard ?? 'Unknown').trim();
      final school = (student.schoolName ?? 'Unknown').trim();
      standardMap[standard] = (standardMap[standard] ?? 0) + 1;
      schoolMap[school] = (schoolMap[school] ?? 0) + 1;
    }
    setState(() {
      _standardCounts = standardMap.entries.toList();
      _schoolCounts = schoolMap.entries.toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Analytics'),
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            tooltip: 'Download All Transactions PDF',
            onPressed: _downloadAllTransactionsPdf,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _analytics == null
              ? const Center(child: Text('No data available'))
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildSummaryCards(),
                      const SizedBox(height: 24),
                      _buildCollectionChart(),
                      const SizedBox(height: 24),
                      _buildStandardBarChart(),
                      const SizedBox(height: 24),
                      _buildSchoolBarChart(),
                    ],
                  ),
                ),
    );
  }

  Widget _buildSummaryCards() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Fee Collection Summary',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _buildSummaryCard(
                'Total Fees',
                '₹${_analytics!['totalFees'].toStringAsFixed(2)}',
                Colors.blue,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildSummaryCard(
                'Collected',
                '₹${_analytics!['totalCollected'].toStringAsFixed(2)}',
                Colors.green,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _buildSummaryCard(
                'Pending',
                '₹${_analytics!['totalPending'].toStringAsFixed(2)}',
                Colors.orange,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildSummaryCard(
                'Collection %',
                '${_analytics!['collectionPercentage'].toStringAsFixed(1)}%',
                Colors.purple,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSummaryCard(String title, String value, Color color) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCollectionChart() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Fee Collection Status',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 200,
          child: PieChart(
            PieChartData(
              sections: [
                PieChartSectionData(
                  color: Colors.green,
                  value: _analytics!['totalCollected'].toDouble(),
                  title: 'Collected',
                  radius: 60,
                  titleStyle: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                PieChartSectionData(
                  color: Colors.orange,
                  value: _analytics!['totalPending'].toDouble(),
                  title: 'Pending',
                  radius: 60,
                  titleStyle: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ],
              sectionsSpace: 0,
              centerSpaceRadius: 40,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStandardBarChart() {
    if (_standardCounts.isEmpty) {
      return const SizedBox.shrink();
    }
    final maxCount = _standardCounts
        .map((e) => e.value)
        .fold<int>(0, (a, b) => a > b ? a : b);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Student Distribution by Standard',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 320,
          child: BarChart(
            BarChartData(
              alignment: BarChartAlignment.spaceAround,
              maxY: (maxCount + 1).toDouble(),
              barTouchData: BarTouchData(enabled: true),
              titlesData: FlTitlesData(
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(showTitles: true, reservedSize: 28),
                ),
                rightTitles: AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
                topTitles: AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (value, meta) {
                      final idx = value.toInt();
                      if (idx < 0 || idx >= _standardCounts.length)
                        return const SizedBox.shrink();
                      return Transform.rotate(
                        angle: -0.5,
                        child: Text(_standardCounts[idx].key,
                            style: const TextStyle(fontSize: 10)),
                      );
                    },
                  ),
                ),
              ),
              borderData: FlBorderData(show: false),
              barGroups: [
                for (int i = 0; i < _standardCounts.length; i++)
                  BarChartGroupData(
                    x: i,
                    barRods: [
                      BarChartRodData(
                        toY: _standardCounts[i].value.toDouble(),
                        color: Colors.blueAccent,
                        width: 32,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ],
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSchoolBarChart() {
    if (_schoolCounts.isEmpty) {
      return const SizedBox.shrink();
    }
    // Ensure unique school names
    final uniqueSchools = <String, int>{};
    for (var entry in _schoolCounts) {
      uniqueSchools[entry.key] = (uniqueSchools[entry.key] ?? 0) + entry.value;
    }
    final schoolList = uniqueSchools.entries.toList();
    final maxCount =
        schoolList.map((e) => e.value).fold<int>(0, (a, b) => a > b ? a : b);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Student Distribution by School',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: (schoolList.length * 36.0).clamp(200, 500),
          child: BarChart(
            BarChartData(
              alignment: BarChartAlignment.center,
              maxY: (maxCount + 1).toDouble(),
              barTouchData: BarTouchData(enabled: true),
              titlesData: FlTitlesData(
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (value, meta) {
                      final idx = value.toInt();
                      if (idx < 0 || idx >= schoolList.length)
                        return const SizedBox.shrink();
                      return Padding(
                        padding: const EdgeInsets.only(right: 8.0),
                        child: Text(schoolList[idx].key,
                            style: const TextStyle(fontSize: 10)),
                      );
                    },
                    reservedSize: 100,
                  ),
                ),
                rightTitles: AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
                topTitles: AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (value, meta) {
                      final idx = value.toInt();
                      if (idx < 0 || idx >= schoolList.length)
                        return const SizedBox.shrink();
                      return Text(schoolList[idx].value.toString(),
                          style: const TextStyle(fontSize: 10));
                    },
                  ),
                ),
              ),
              borderData: FlBorderData(show: false),
              barGroups: [
                for (int i = 0; i < schoolList.length; i++)
                  BarChartGroupData(
                    x: i,
                    barRods: [
                      BarChartRodData(
                        toY: schoolList[i].value.toDouble(),
                        color: Colors.deepPurpleAccent,
                        width: 32,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ],
                  ),
              ],
              gridData: FlGridData(show: false),
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _downloadAllTransactionsPdf() async {
    final studentProvider =
        Provider.of<StudentProvider>(context, listen: false);
    final students = studentProvider.students;
    final List<MapEntry<Student, Payment>> allPayments = [];
    for (final student in students) {
      final payments = await studentProvider.getStudentPayments(student.id);
      allPayments.addAll(payments.map((p) => MapEntry(student, p)));
    }

    final pdf = pw.Document();
    pdf.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Header(
              level: 0,
              child: pw.Text('All Payment Transactions',
                  style: pw.TextStyle(
                      fontSize: 24, fontWeight: pw.FontWeight.bold))),
          pw.Table.fromTextArray(
            headers: [
              'Student Name',
              'Class',
              'School',
              'Parent Contact',
              'Payment Date',
              'Amount',
              'Mode',
              'Notes',
              'Remaining Fees',
            ],
            data: allPayments.map((entry) {
              final student = entry.key;
              final payment = entry.value;
              return [
                student.name,
                student.standard,
                student.schoolName,
                student.parentNumber,
                payment.paymentDate.toString().substring(0, 16),
                payment.amount.toStringAsFixed(2),
                payment.paymentMode,
                payment.notes ?? '-',
                student.remainingFees.toStringAsFixed(2),
              ];
            }).toList(),
            cellStyle: const pw.TextStyle(fontSize: 10),
            headerStyle:
                pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 12),
            headerDecoration: pw.BoxDecoration(color: PdfColors.grey300),
            cellAlignment: pw.Alignment.centerLeft,
            columnWidths: {
              0: const pw.FlexColumnWidth(2), // Student Name
              1: const pw.FlexColumnWidth(1), // Class
              2: const pw.FlexColumnWidth(2), // School
              3: const pw.FlexColumnWidth(2), // Parent Contact
              4: const pw.FlexColumnWidth(2), // Payment Date
              5: const pw.FlexColumnWidth(1), // Amount
              6: const pw.FlexColumnWidth(1), // Mode
              7: const pw.FlexColumnWidth(2), // Notes
              8: const pw.FlexColumnWidth(1), // Remaining Fees
            },
          ),
        ],
      ),
    );
    await Printing.layoutPdf(onLayout: (format) async => pdf.save());
  }
}
